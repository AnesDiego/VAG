Bit is written and maintained by Ofek Lev.

Maintainers
-----------

- Ofek Lev <ofekmeister@gmail.com> `@ofek <https://github.com/ofek>`_

Contributors
------------

Any PGP key fingerprints are enclosed in parentheses.

- Ofek Lev <ofekmeister@gmail.com> (FFB6 B92B 30B1 7848 546E 9912 972F E913 DAD5 A46E)
- Teran McKinney <sega01@go-beyond.org> (B372 6B4F 1567 9D12 6041  7D43 649B 929C 02EF 2CF2)
- Bjarne Magnussen <bjarne@magnussen.casa> (F407 022B 0951 2719 7668 3BE0 B0A9 ADF6 B24C E67F)

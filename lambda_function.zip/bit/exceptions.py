class InsufficientFunds(Exception):
    pass


class BitcoinNodeException(Exception):
    pass

class ExcessiveAddress(Exception):
    pass
